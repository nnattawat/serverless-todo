## Serverless API for todo app

# Runing locally

```bash
# install packages
npm i

# create local dynamodb table, run this once
npm run db:create

# start server
# note that you need Java installed for running serverless-dynamodb-local
npm run start
```

# Deploy

You will need to setup AWS credential in your local machine. In my case I put them in `~/.aws/credentials`.

```bash
# deploy stack
npm run deploy
```

Sometimes you only want to upload new source code for your function without changing your stack.
```bash
# update function's code
npm run deploy:function
```

You can destroy the stack by running:
```bash
# remove stack
npm run destroy
```
