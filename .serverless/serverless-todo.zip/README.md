## Serverless API for todo app

# Runing

```bash
npm i
```

# Deploy

You will need to setup AWS credential in your local machine. In my case I put them in `~/.aws/credentials`.

```bash
npm run deploy
```

You cab destroy the stack by running:
```bash
npm run remove
```
